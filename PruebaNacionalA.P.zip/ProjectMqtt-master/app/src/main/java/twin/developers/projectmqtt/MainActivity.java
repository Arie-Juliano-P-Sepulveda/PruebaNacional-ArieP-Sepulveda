package twin.developers.projectmqtt;

import android.content.pm.PackageManager;
import android.location.Location;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import com.google.android.gms.location.LocationCallback;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

public class MainActivity extends AppCompatActivity {

    private Mqtt mqttManager;
    private EditText texto;
    private Button btnEnviar;
    private LocationProvider locationProvider;

    private final LocationProvider.LocationCallback locationCallback = new LocationProvider.LocationCallback() {
        @Override
        public void onLocationResult(Location location) {
            if (location != null) {
                mqttManager.publishLocation(location);
                locationProvider.removeLocationUpdates(locationCallback);
            }
        }
    };

    private static final int REQUEST_LOCATION_PERMISSION = 1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        texto = findViewById(R.id.txtMessage);
        btnEnviar = findViewById(R.id.btnLocal);

        mqttManager = new Mqtt(getApplicationContext());
        mqttManager.connectToMqttBroker();

        locationProvider = new LocationProvider(this);

        btnEnviar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (checkLocationPermission()) {
                    locationProvider.requestLocationUpdates(locationCallback);
                }
            }
        });
    }

    private boolean checkLocationPermission() {
        if (ContextCompat.checkSelfPermission(this,
                android.Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {

            ActivityCompat.requestPermissions(this,
                    new String[]{android.Manifest.permission.ACCESS_FINE_LOCATION},
                    REQUEST_LOCATION_PERMISSION);
            return false;
        }
        return true;
    }

    @Override
    public void onRequestPermissionsResult(int requestCode,
                                           @NonNull String[] permissions, @NonNull int[] grantResults) {
        if (requestCode == REQUEST_LOCATION_PERMISSION) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                locationProvider.requestLocationUpdates(locationCallback);
            } else {
                texto.setText("Permiso de ubicación denegado");
            }
        }
    }
}

