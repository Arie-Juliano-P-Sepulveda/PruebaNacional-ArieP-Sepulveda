package twin.developers.projectmqtt;

import android.content.Context;
import android.location.Location;
import android.os.Looper;
import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationCallback;
import com.google.android.gms.location.LocationRequest;
import com.google.android.gms.tasks.OnSuccessListener;

public class LocationProvider {

    private final Context context;
    private final FusedLocationProviderClient fusedLocationProviderClient;

    public LocationProvider(Context context) {
        this.context = context;
        this.fusedLocationProviderClient = new FusedLocationProviderClient(context);
    }

    public Location getLastKnownLocation() {
        try {
            fusedLocationProviderClient.getLastLocation()
                    .addOnSuccessListener(new OnSuccessListener<Location>() {
                        @Override
                        public void onSuccess(Location location) {
                            if (location != null) {

                            }
                        }
                    });
        } catch (SecurityException e) {
            e.printStackTrace();
        }
        return null;
    }

    public void requestLocationUpdates(LocationCallback locationCallback) {
        try {
            LocationRequest locationRequest = new LocationRequest();
            locationRequest.setPriority(LocationRequest.PRIORITY_HIGH_ACCURACY);
            locationRequest.setInterval(5000); // 5 segundos

            fusedLocationProviderClient.requestLocationUpdates(locationRequest, locationCallback, Looper.getMainLooper());
        } catch (SecurityException e) {
            e.printStackTrace();
        }
    }

    public void removeLocationUpdates(LocationCallback locationCallback) {
        fusedLocationProviderClient.removeLocationUpdates(locationCallback);
    }
}
